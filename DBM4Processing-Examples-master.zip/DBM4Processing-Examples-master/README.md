## DBM4Processing-Examples 
Here are examples of how to create and use databases in your sketches. 
This job is focused mainly in Derby (aka Java DB) because that RDBMS has been included with
the distributed package of Java since Java 6.0, so it is not necesary to add any more to use it with sketches.
Nevertheless, it is possible to use other DBMSs such as MySQL with few modifications (plus the installation of MySQL, of course). 
