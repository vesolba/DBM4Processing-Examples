
## PImagewithBlob

This example shows how to create a database with blobs and how to insert and load images on it. 
After its execution you will see an output sketch window like this 

[![Image](https://github.com/vesolba/DBManager-for-Processing/blob/master/examples/PImagewithBlob/Captura.PNG)](https://github.com/vesolba/DBManager-for-Processing/blob/master/examples/PImagewithBlob/Captura.PNG)

As you can see in the above image, the code of the example has been distributed in four ".pde" files, one with the main
sentences and tree more with several functions that you can use with little or not modifications in your projects.
